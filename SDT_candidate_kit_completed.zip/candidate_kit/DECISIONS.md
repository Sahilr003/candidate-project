# Decisions

1. **Indexes.** I enforce unique `emp_code` and unique `(emp_code, date)` indexes because they are business invariants and make concurrent duplicates safe. I added department/join-date indexes for headcount filters, date/employee ordering for attendance pages, status/date for filtered listing, and date/late-minute ordering for monthly late queries. I would avoid speculative indexes on every field because they increase write cost and storage.

2. **Punch-in race.** Both requests may look up the employee and build the same attendance key. MongoDB's unique compound index allows only one insert; the winner receives 201 and the duplicate-key loser receives 409. Correctness does not depend on a prior existence check.

3. **Ties.** Ranking uses MongoDB `$rank` on total late minutes, then filters ranks at or below `limit`. Tied people share a rank, so a tie at the cutoff can return more than `limit` rows; response order then uses employee code.

4. **Headcount.** The department summary starts with eligible employees, then looks up attendance. Employees with no logs remain in the pipeline and count toward headcount.

5. **100x scale.** I would validate plans against production-like data, consider pre-aggregated daily metrics, and monitor index selectivity and aggregation memory before adding infrastructure.
