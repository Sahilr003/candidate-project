"""Employee Attendance & Analytics API (assignment implementation)."""
import os, re, calendar, math
from datetime import datetime, date, time, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional, Literal, Any

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query, Path
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from pymongo import MongoClient, ASCENDING, DESCENDING, ReturnDocument
from pymongo.errors import DuplicateKeyError, OperationFailure, PyMongoError
from bson import ObjectId, json_util

load_dotenv()
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
MONGO_DB = os.getenv("MONGO_DB", "attendance_db")
client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=2500, tz_aware=False)
db = client[MONGO_DB]
IST = timezone(timedelta(hours=5, minutes=30))
UTC = timezone.utc
PRESENCE = {"PRESENT", "WFH", "ON_DUTY"}
STATUSES = PRESENCE | {"ABSENT", "LEAVE"}
app = FastAPI(title="Employee Attendance & Analytics API", version="2.0.0")


def utcnow():
    return datetime.now(UTC).replace(microsecond=0).replace(tzinfo=None)


def parse_date(value: str) -> date:
    try:
        d = date.fromisoformat(value)
        if d.isoformat() != value: raise ValueError()
        return d
    except (ValueError, TypeError):
        raise HTTPException(422, "date must be YYYY-MM-DD")


def validate_month(value: str) -> tuple[date, date]:
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", value or ""):
        raise HTTPException(422, "month must be YYYY-MM")
    y, m = map(int, value.split("-")); last = calendar.monthrange(y, m)[1]
    return date(y, m, 1), date(y, m, last)


def epoch_to_dt(ms: int | None) -> datetime | None:
    if ms is None: return None
    # Pydantic rejects floats/strings, this guards the range at the boundary too.
    if type(ms) is not int or ms < 100_000_000_000 or ms > 4_102_444_800_000:
        raise HTTPException(422, "timestamp must be epoch milliseconds in supported range")
    return datetime.fromtimestamp(ms / 1000, UTC).replace(microsecond=0, tzinfo=None)


def dt_to_epoch(value: datetime | None) -> int | None:
    if value is None: return None
    if value.tzinfo is None: value = value.replace(tzinfo=UTC)
    return int(value.timestamp() * 1000)


def api_doc(doc: dict) -> dict:
    out = {k: v for k, v in doc.items() if k != "_id"}
    for k in ("created_at", "punch_in", "punch_out"):
        if k in out: out[k] = dt_to_epoch(out[k])
    hist = []
    for h in out.get("history", []) or []:
        nh = dict(h); nh["at"] = dt_to_epoch(nh.get("at"))
        changes = {}
        for field, pair in (nh.get("changes") or {}).items():
            pair = dict(pair)
            if field in ("punch_in", "punch_out"):
                pair["from"] = dt_to_epoch(pair.get("from")); pair["to"] = dt_to_epoch(pair.get("to"))
            changes[field] = pair
        nh["changes"] = changes; hist.append(nh)
    if "history" in out: out["history"] = hist
    return out


def mongo_json(value: Any):
    # Extended JSON is used only to normalize BSON-only values in explain output.
    return json_util.loads(json_util.dumps(value, json_options=json_util.RELAXED_JSON_OPTIONS))


def shift_dt(day: date, hhmm: str) -> datetime:
    h, m = map(int, hhmm.split(":"))
    return datetime.combine(day, time(h, m), IST).astimezone(UTC).replace(tzinfo=None)


def attendance_day(punch_in: datetime, emp: dict) -> date:
    local = punch_in.replace(tzinfo=UTC).astimezone(IST)
    d = local.date()
    if emp["shift_end"] <= emp["shift_start"] and local.strftime("%H:%M") < emp["shift_end"]:
        d -= timedelta(days=1)
    return d


def late_minutes(punch_in: datetime | None, shift_start: str, day: str) -> int:
    if punch_in is None: return 0
    start = shift_dt(parse_date(day), shift_start)
    # If shift began previous day due to overnight date assignment, the shift start is the record day.
    elapsed = math.floor((punch_in - start).total_seconds() / 60)
    return elapsed if (punch_in - start).total_seconds() > 600 else 0


def work_hours(punch_in: datetime | None, punch_out: datetime | None) -> float | None:
    if punch_in is None or punch_out is None: return None
    hours = Decimal(str((punch_out - punch_in).total_seconds())) / Decimal(3600)
    return float(hours.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def overtime_minutes(punch_out: datetime | None, shift_end: str, day: str) -> int:
    if punch_out is None: return 0
    d = parse_date(day); h, m = map(int, shift_end.split(":"))
    end_day = d + timedelta(days=1) if shift_end <= "00:00" else d
    # All shift_end <= shift_start is overnight; caller passes employee separately below where needed.
    end = shift_dt(end_day, shift_end)
    delta = math.floor((punch_out - end).total_seconds() / 60)
    return delta if delta >= 30 else 0


def overtime_for_employee(punch_out, emp, day):
    d = parse_date(day)
    if emp["shift_end"] <= emp["shift_start"]: d += timedelta(days=1)
    end = shift_dt(d, emp["shift_end"])
    mins = math.floor((punch_out - end).total_seconds() / 60)
    return mins if mins >= 30 else 0


def validate_page(page: int, page_size: int):
    if page < 1: raise HTTPException(422, "page must be >= 1")
    if page_size < 1 or page_size > 100: raise HTTPException(422, "page_size must be between 1 and 100")


def create_indexes():
    db.employees.create_index([("emp_code", ASCENDING)], unique=True, name="uq_employee_code")
    db.employees.create_index([("department", ASCENDING), ("joined_on", ASCENDING)], name="department_joined")
    db.employees.create_index([("joined_on", ASCENDING), ("department", ASCENDING)], name="joined_department")
    db.attendance_logs.create_index([("emp_code", ASCENDING), ("date", ASCENDING)], unique=True, name="uq_attendance_employee_date")
    db.attendance_logs.create_index([("date", DESCENDING), ("emp_code", ASCENDING)], name="attendance_date_emp")
    db.attendance_logs.create_index([("status", ASCENDING), ("date", ASCENDING)], name="attendance_status_date")
    db.attendance_logs.create_index([("date", ASCENDING), ("late_minutes", DESCENDING), ("emp_code", ASCENDING)], name="attendance_date_late")

@app.on_event("startup")
def startup():
    try: create_indexes()
    except PyMongoError: pass  # readiness endpoint reports the outage; startup remains inspectable


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

class EmployeeIn(StrictModel):
    emp_code: str = Field(pattern=r"^EMP\d{4,6}$")
    name: str = Field(min_length=1, max_length=100)
    email: str = Field(max_length=120, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    department: str = Field(min_length=1, max_length=50)
    shift_start: str = Field(default="09:30", pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    shift_end: str = Field(default="18:30", pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    joined_on: str
    @field_validator("joined_on")
    @classmethod
    def valid_joined(cls, v): parse_date(v); return v
    @model_validator(mode="after")
    def shifts_differ(self):
        if self.shift_start == self.shift_end: raise ValueError("shift_start must differ from shift_end")
        return self

class PunchInIn(StrictModel):
    emp_code: str
    punched_at: int | None = Field(default=None, strict=True)
    status: Literal["PRESENT", "WFH", "ON_DUTY"] = "PRESENT"
    @field_validator("punched_at")
    @classmethod
    def valid_ts(cls, v):
        if v is not None and (type(v) is not int or not 100_000_000_000 <= v <= 4_102_444_800_000): raise ValueError("punched_at must be epoch milliseconds")
        return v

class PunchOutIn(StrictModel):
    emp_code: str
    punched_at: int | None = Field(default=None, strict=True)
    @field_validator("punched_at")
    @classmethod
    def valid_ts(cls, v):
        if v is not None and (type(v) is not int or not 100_000_000_000 <= v <= 4_102_444_800_000): raise ValueError("punched_at must be epoch milliseconds")
        return v

class RegularizeIn(StrictModel):
    status: Literal["PRESENT", "ABSENT", "LEAVE", "WFH", "ON_DUTY"] = None
    punch_in: int = Field(default=None, strict=True)
    punch_out: int = Field(default=None, strict=True)
    reason: str = Field(min_length=5, max_length=200)
    regularized_by: str = Field(min_length=1, max_length=50)
    @field_validator("punch_in", "punch_out")
    @classmethod
    def valid_ts(cls, v):
        if v is not None and (type(v) is not int or not 100_000_000_000 <= v <= 4_102_444_800_000): raise ValueError("timestamps must be epoch milliseconds")
        return v

@app.get("/health")
def health():
    try: db.command("ping"); return {"status": "ok"}
    except PyMongoError: raise HTTPException(503, "MongoDB unavailable")

@app.post("/employees", status_code=201)
def create_employee(body: EmployeeIn):
    doc = body.model_dump(); doc["created_at"] = utcnow()
    try: db.employees.insert_one(doc)
    except DuplicateKeyError: raise HTTPException(409, "emp_code already exists")
    return api_doc(doc)

@app.get("/employees")
def list_employees(department: str | None = None, page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    q = {"department": department} if department is not None else {}
    total = db.employees.count_documents(q)
    items = list(db.employees.find(q, {"_id": 0}).sort("emp_code", ASCENDING).skip((page-1)*page_size).limit(page_size))
    for x in items: x["created_at"] = dt_to_epoch(x["created_at"])
    return {"items": items, "total": total, "page": page, "page_size": page_size}

@app.post("/attendance/punch-in", status_code=201)
def punch_in(body: PunchInIn):
    emp = db.employees.find_one({"emp_code": body.emp_code})
    if not emp: raise HTTPException(404, "unknown employee")
    ts = epoch_to_dt(body.punched_at) if body.punched_at is not None else utcnow()
    ts = ts.replace(microsecond=0)
    day = attendance_day(ts, emp).isoformat()
    doc = {"emp_code": body.emp_code, "date": day, "status": body.status, "punch_in": ts, "punch_out": None,
           "work_hours": None, "late_minutes": late_minutes(ts, emp["shift_start"], day), "overtime_minutes": 0, "half_day": False, "history": []}
    try: db.attendance_logs.insert_one(doc)
    except DuplicateKeyError: raise HTTPException(409, "already punched in for this date")
    return api_doc(doc)

@app.post("/attendance/punch-out")
def punch_out(body: PunchOutIn):
    emp = db.employees.find_one({"emp_code": body.emp_code})
    if not emp: raise HTTPException(404, "unknown employee")
    ts = epoch_to_dt(body.punched_at) if body.punched_at is not None else utcnow()
    ts = ts.replace(microsecond=0)
    record = db.attendance_logs.find_one({"emp_code": body.emp_code, "punch_in": {"$lte": ts}}, sort=[("punch_in", DESCENDING)])
    if not record: raise HTTPException(404, "no punch-in found")
    if record.get("punch_out") is not None: raise HTTPException(409, "record already punched out")
    if ts <= record["punch_in"] or ts > record["punch_in"] + timedelta(hours=24): raise HTTPException(422, "punch-out must be after punch-in and within 24 hours")
    wh = work_hours(record["punch_in"], ts); ot = overtime_for_employee(ts, emp, record["date"])
    updated = db.attendance_logs.find_one_and_update({"_id": record["_id"], "punch_out": None}, {"$set": {"punch_out": ts, "work_hours": wh, "overtime_minutes": ot, "half_day": wh < 4.50}}, return_document=ReturnDocument.AFTER)
    if not updated: raise HTTPException(409, "record already punched out")
    return api_doc(updated)

@app.get("/attendance")
def list_attendance(emp_code: str | None = None, date_from: str | None = None, date_to: str | None = None,
                    status: str | None = None, page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    if status is not None and status not in STATUSES: raise HTTPException(422, "invalid status")
    if date_from: parse_date(date_from)
    if date_to: parse_date(date_to)
    if date_from and date_to and date_from > date_to: raise HTTPException(422, "date_from must be <= date_to")
    q = {}
    if emp_code is not None: q["emp_code"] = emp_code
    if date_from or date_to:
        q["date"] = {}
        if date_from: q["date"]["$gte"] = date_from
        if date_to: q["date"]["$lte"] = date_to
    if status is not None: q["status"] = status
    total = db.attendance_logs.count_documents(q)
    docs = list(db.attendance_logs.find(q, {"_id": 0}).sort([("date", DESCENDING), ("emp_code", ASCENDING)]).skip((page-1)*page_size).limit(page_size))
    return {"items": [api_doc(x) for x in docs], "total": total, "page": page, "page_size": page_size}

@app.patch("/attendance/{emp_code}/{date}")
def regularize(emp_code: str, date: str, body: RegularizeIn):
    d = parse_date(date).isoformat()
    emp = db.employees.find_one({"emp_code": emp_code})
    if not emp: raise HTTPException(404, "unknown employee")
    old = db.attendance_logs.find_one({"emp_code": emp_code, "date": d})
    if not old: raise HTTPException(404, "attendance record not found")
    new = {k: old.get(k) for k in ("status", "punch_in", "punch_out", "work_hours", "late_minutes", "overtime_minutes", "half_day")}
    incoming = body.model_dump(exclude_unset=True)
    for k in ("status", "punch_in", "punch_out"):
        if k in incoming and incoming[k] is not None:
            new[k] = incoming[k] if k == "status" else epoch_to_dt(incoming[k])
        elif k in incoming and incoming[k] is None and k != "status": new[k] = None
    if new["status"] in {"ABSENT", "LEAVE"}:
        if ("punch_in" in incoming and incoming.get("punch_in") is not None) or ("punch_out" in incoming and incoming.get("punch_out") is not None): raise HTTPException(422, "ABSENT/LEAVE cannot include punch times")
        new["punch_in"] = new["punch_out"] = None; new.update(work_hours=None, late_minutes=0, overtime_minutes=0, half_day=False)
    else:
        if new["punch_in"] is None: raise HTTPException(422, "presence status requires punch_in")
        if attendance_day(new["punch_in"], emp).isoformat() != d: raise HTTPException(422, "punch_in must belong to attendance date")
        if new["punch_out"] is not None:
            if new["punch_out"] <= new["punch_in"] or new["punch_out"] > new["punch_in"] + timedelta(hours=24): raise HTTPException(422, "invalid punch_out")
            new["work_hours"] = work_hours(new["punch_in"], new["punch_out"]); new["overtime_minutes"] = overtime_for_employee(new["punch_out"], emp, d); new["half_day"] = new["work_hours"] < 4.50
        else: new["work_hours"] = None; new["overtime_minutes"] = 0; new["half_day"] = False
        new["late_minutes"] = late_minutes(new["punch_in"], emp["shift_start"], d)
    changes = {}
    for k, v in new.items():
        ov = old.get(k)
        if ov != v: changes[k] = {"from": ov, "to": v}
    if not changes: raise HTTPException(422, "regularization changes nothing")
    at = utcnow(); entry = {"at": at, "by": body.regularized_by, "reason": body.reason, "changes": changes}
    # Optimistic concurrency check: only update if every original editable/derived value is unchanged.
    guard = {"_id": old["_id"]}
    for k in ("status", "punch_in", "punch_out", "work_hours", "late_minutes", "overtime_minutes", "half_day"):
        guard[k] = old.get(k, None)
    set_values = {k: v for k, v in new.items()}
    updated = db.attendance_logs.find_one_and_update(guard, {"$set": set_values, "$push": {"history": entry}}, return_document=ReturnDocument.AFTER)
    if not updated: raise HTTPException(409, "record changed concurrently; retry")
    return api_doc(updated)

# Aggregation expressions used by analytics. Calendar strings sort lexically in ISO format.
def presence_expr(): return {"$in": ["$status", ["PRESENT", "WFH", "ON_DUTY"]]}
def month_match(month):
    start, end = validate_month(month)
    return start.isoformat(), end.isoformat()
def round_decimal(value, places=2):
    if value is None: return None
    return float(Decimal(str(value)).quantize(Decimal("1." + "0"*places), rounding=ROUND_HALF_UP))
def weekdays(start: date, end: date):
    n=0; d=start
    while d<=end:
        if d.weekday()<5: n+=1
        d+=timedelta(days=1)
    return n

@app.get("/analytics/employees/{emp_code}/monthly")
def employee_monthly(emp_code: str, month: str = Query(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])$")):
    emp = db.employees.find_one({"emp_code": emp_code}, {"_id": 0})
    if not emp: raise HTTPException(404, "unknown employee")
    first, last = month_match(month)
    rows = list(db.attendance_logs.aggregate([
        {"$match": {"emp_code": emp_code, "date": {"$gte": first, "$lte": last}}},
        {"$group": {"_id": None,
            "present_days": {"$sum": {"$cond": [{"$and": [presence_expr(), {"$not": [{"$in": [{"$dayOfWeek": {"$dateFromString": {"dateString": "$date", "format": "%Y-%m-%d", "timezone": "UTC"}}}, [1, 7]]}]}]}, {"$cond": [{"$eq": ["$half_day", True]}, 0.5, 1]}, 0]}},
            "leave_days": {"$sum": {"$cond": [{"$eq": ["$status", "LEAVE"]}, 1, 0]}},
            "late_count": {"$sum": {"$cond": [{"$gt": [{"$ifNull": ["$late_minutes", 0]}, 0]}, 1, 0]}},
            "total_late_minutes": {"$sum": {"$ifNull": ["$late_minutes", 0]}},
            "total_overtime_minutes": {"$sum": {"$ifNull": ["$overtime_minutes", 0]}}}}
    ]))
    x = rows[0] if rows else {}
    start, end = date.fromisoformat(first), date.fromisoformat(last)
    working = weekdays(max(start, date.fromisoformat(emp["joined_on"])), end) if date.fromisoformat(emp["joined_on"]) <= end else 0
    present = round_decimal(x.get("present_days", 0))
    pct = round_decimal(present / working * 100, 2) if working else None
    return {"emp_code": emp_code, "month": month, "working_days": working, "present_days": present, "leave_days": x.get("leave_days", 0), "late_count": x.get("late_count", 0), "total_late_minutes": x.get("total_late_minutes", 0), "total_overtime_minutes": x.get("total_overtime_minutes", 0), "attendance_pct": pct}

@app.get("/analytics/departments/summary")
def department_summary(month: str = Query(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])$"), department: str | None = None):
    first, last = month_match(month)
    pipeline = [
      {"$match": {"joined_on": {"$lte": last}, **({"department": department} if department is not None else {})}},
      {"$lookup": {"from": "attendance_logs", "let": {"code": "$emp_code"}, "pipeline": [{"$match": {"$expr": {"$and": [{"$eq": ["$emp_code", "$$code"]}, {"$gte": ["$date", first]}, {"$lte": ["$date", last]}]}}}], "as": "logs"}},
      {"$unwind": {"path": "$logs", "preserveNullAndEmptyArrays": True}},
      {"$group": {"_id": "$department", "headcount": {"$sum": {"$cond": [{"$eq": [{"$ifNull": ["$logs", None]}, None]}, 1, 0]}},
       "employee_codes": {"$addToSet": "$emp_code"},
       "present_days": {"$sum": {"$cond": [{"$in": ["$logs.status", ["PRESENT", "WFH", "ON_DUTY"]]}, {"$cond": [{"$not": [{"$in": [{"$dayOfWeek": {"$dateFromString": {"dateString": "$logs.date", "format": "%Y-%m-%d", "timezone": "UTC", "onNull": None, "onError": None}}}, [1, 7]]}]}, {"$cond": [{"$eq": ["$logs.half_day", True]}, 0.5, 1]}, 0]}, 0]}},
       "work_hours_sum": {"$sum": {"$cond": [{"$and": [{"$in": ["$logs.status", ["PRESENT", "WFH", "ON_DUTY"]]}, {"$ne": ["$logs.work_hours", None]}]}, "$logs.work_hours", 0]}},
       "work_hours_count": {"$sum": {"$cond": [{"$and": [{"$in": ["$logs.status", ["PRESENT", "WFH", "ON_DUTY"]]}, {"$ne": ["$logs.work_hours", None]}]}, 1, 0]}},
       "late_count": {"$sum": {"$cond": [{"$gt": [{"$ifNull": ["$logs.late_minutes", 0]}, 0]}, 1, 0]}},
       "total_late_minutes": {"$sum": {"$ifNull": ["$logs.late_minutes", 0]}},
       "leave_count": {"$sum": {"$cond": [{"$eq": ["$logs.status", "LEAVE"]}, 1, 0]}},
       "on_duty_count": {"$sum": {"$cond": [{"$eq": ["$logs.status", "ON_DUTY"]}, 1, 0]}}}},
      {"$project": {"_id": 0, "department": "$_id", "headcount": {"$size": "$employee_codes"}, "present_days": {"$round": ["$present_days", 2]}, "avg_work_hours": {"$cond": [{"$gt": ["$work_hours_count", 0]}, {"$divide": [{"$floor": {"$add": [{"$multiply": [{"$divide": ["$work_hours_sum", "$work_hours_count"]}, 100]}, 0.5]}}, 100]}, None]}, "late_count": 1, "total_late_minutes": 1, "leave_count": 1, "on_duty_count": 1}},
      {"$sort": {"department": 1}}
    ]
    return {"month": month, "items": list(db.employees.aggregate(pipeline))}

@app.get("/analytics/leaderboard/late")
def late_leaderboard(month: str = Query(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])$"), limit: int = Query(10, ge=1, le=50), department: str | None = None):
    first, last = month_match(month)
    pipeline = [
      {"$match": {"date": {"$gte": first, "$lte": last}}},
      {"$group": {"_id": "$emp_code", "total_late_minutes": {"$sum": {"$ifNull": ["$late_minutes", 0]}}, "late_count": {"$sum": {"$cond": [{"$gt": [{"$ifNull": ["$late_minutes", 0]}, 0]}, 1, 0]}}}},
      {"$match": {"total_late_minutes": {"$gt": 0}}},
      {"$lookup": {"from": "employees", "localField": "_id", "foreignField": "emp_code", "as": "employee"}}, {"$unwind": "$employee"},
    ]
    if department is not None: pipeline.append({"$match": {"employee.department": department}})
    pipeline += [
      {"$sort": {"total_late_minutes": -1, "_id": 1}},
      {"$setWindowFields": {"sortBy": {"total_late_minutes": -1}, "output": {"rank": {"$rank": {}}}}},
      {"$match": {"rank": {"$lte": limit}}},
      {"$project": {"_id": 0, "rank": 1, "emp_code": "$_id", "name": "$employee.name", "department": "$employee.department", "total_late_minutes": 1, "late_count": 1}},
      {"$sort": {"total_late_minutes": -1, "emp_code": 1}}
    ]
    return {"month": month, "items": list(db.attendance_logs.aggregate(pipeline))}

@app.get("/analytics/departments/{department}/trend")
def department_trend(department: str, from_date: str = Query(..., alias="from"), to_date: str = Query(..., alias="to")):
    start, end = parse_date(from_date), parse_date(to_date)
    if end < start or (end-start).days+1 > 92:
        raise HTTPException(422, "invalid range: to must be >= from and range <= 92 days")
    if not db.employees.find_one({"department": department}):
        raise HTTPException(404, "unknown department")
    # Start from the department itself, so dates are generated even when no attendance logs exist.
    start_dt = datetime.combine(start, time.min)
    day_count = (end - start).days + 1
    pipeline = [
      {"$match": {"department": department}},
      {"$group": {"_id": "$department", "emp_codes": {"$addToSet": "$emp_code"}}},
      {"$set": {"dates": {"$map": {"input": {"$range": [0, day_count]}, "as": "offset", "in": {"$dateAdd": {"startDate": start_dt, "unit": "day", "amount": "$$offset"}}}}}},
      {"$unwind": "$dates"},
      {"$set": {"date_str": {"$dateToString": {"date": "$dates", "format": "%Y-%m-%d", "timezone": "UTC"}}}},
      {"$lookup": {"from": "attendance_logs", "let": {"d": "$date_str"}, "pipeline": [
        {"$match": {"$expr": {"$eq": ["$date", "$$d"]}}},
        {"$lookup": {"from": "employees", "localField": "emp_code", "foreignField": "emp_code", "as": "employee"}},
        {"$unwind": "$employee"}, {"$match": {"employee.department": department}},
        {"$project": {"_id": 0, "status": 1, "half_day": 1, "late_minutes": 1}}
      ], "as": "logs"}},
      {"$lookup": {"from": "employees", "let": {"d": "$date_str"}, "pipeline": [{"$match": {"$expr": {"$and": [{"$eq": ["$department", department]}, {"$lte": ["$joined_on", "$$d"]}]}}}, {"$count": "n"}], "as": "hc"}},
      {"$set": {
        "headcount": {"$ifNull": [{"$arrayElemAt": ["$hc.n", 0]}, 0]},
        "present_count": {"$reduce": {"input": "$logs", "initialValue": 0, "in": {"$add": ["$$value", {"$cond": [{"$in": ["$$this.status", ["PRESENT", "WFH", "ON_DUTY"]]}, {"$cond": [{"$eq": ["$$this.half_day", True]}, 0.5, 1]}, 0]}]}}},
        "late_count": {"$reduce": {"input": "$logs", "initialValue": 0, "in": {"$add": ["$$value", {"$cond": [{"$gt": [{"$ifNull": ["$$this.late_minutes", 0]}, 0]}, 1, 0]}]}}},
        "is_working_day": {"$not": [{"$in": [{"$dayOfWeek": "$dates"}, [1, 7]]}]}
      }},
      {"$set": {"attendance_rate": {"$cond": [{"$and": ["$is_working_day", {"$gt": ["$headcount", 0]}]}, {"$divide": [{"$floor": {"$add": [{"$multiply": [{"$divide": ["$present_count", "$headcount"]}, 10000]}, 0.5]}}, 10000]}, None]}}},
      {"$setWindowFields": {"sortBy": {"dates": 1}, "output": {"moving_avg_7d": {"$avg": "$attendance_rate", "window": {"documents": [-6, 0]}}}}},
      {"$project": {"_id": 0, "date": "$date_str", "is_working_day": 1, "headcount": 1, "present_count": 1, "late_count": 1, "attendance_rate": 1, "moving_avg_7d": {"$cond": [{"$eq": ["$moving_avg_7d", None]}, None, {"$divide": [{"$floor": {"$add": [{"$multiply": ["$moving_avg_7d", 10000]}, 0.5]}}, 10000]}]}}},
      {"$sort": {"date": 1}}
    ]
    return {"department": department, "items": list(db.employees.aggregate(pipeline))}

# Explain diagnostics use the same filter/sort/pagination definitions as their corresponding endpoints.
def explain_find(collection, query, sort, skip, limit):
    cmd = {"find": collection.name, "filter": query, "sort": {k: v for k, v in sort}, "skip": skip, "limit": limit}
    return db.command("explain", cmd, verbosity="executionStats")
def explain_aggregate(collection, pipeline):
    return db.command("explain", {"aggregate": collection.name, "pipeline": pipeline, "cursor": {}}, verbosity="executionStats")

@app.get("/admin/explain/{endpoint}")
def explain_endpoint(endpoint: str = Path(..., pattern="^(attendance_list|employee_monthly|department_summary|late_leaderboard|department_trend)$"),
                     emp_code: str | None = None, month: str | None = None, department: str | None = None,
                     limit: int = Query(10, ge=1, le=50), date_from: str | None = None, date_to: str | None = None,
                     status: str | None = None, from_date: str | None = Query(None, alias="from"), to_date: str | None = Query(None, alias="to"),
                     page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    if endpoint == "attendance_list":
        if date_from: parse_date(date_from)
        if date_to: parse_date(date_to)
        if date_from and date_to and date_from > date_to: raise HTTPException(422, "invalid date range")
        q={}
        if emp_code is not None:q["emp_code"]=emp_code
        if date_from or date_to:
            q["date"]={}
            if date_from:q["date"]["$gte"]=date_from
            if date_to:q["date"]["$lte"]=date_to
        if status is not None:
            if status not in STATUSES: raise HTTPException(422,"invalid status")
            q["status"]=status
        exp=explain_find(db.attendance_logs,q,[("date",DESCENDING),("emp_code",ASCENDING)],(page-1)*page_size,page_size); coll="attendance_logs"
    else:
        if not month: raise HTTPException(422,"month is required")
        first,last=month_match(month)
        if endpoint == "employee_monthly":
            if not emp_code: raise HTTPException(422,"emp_code is required")
            pipe=[{"$match":{"emp_code":emp_code,"date":{"$gte":first,"$lte":last}}},{"$group":{"_id":"$emp_code","late_count":{"$sum":{"$cond":[{"$gt":["$late_minutes",0]},1,0]}}}}]
            exp=explain_aggregate(db.attendance_logs,pipe); coll="attendance_logs"
        elif endpoint == "department_summary":
            pipe=[{"$match":{"joined_on":{"$lte":last},**({"department":department} if department else {})}},{"$lookup":{"from":"attendance_logs","localField":"emp_code","foreignField":"emp_code","as":"logs"}},{"$limit":100000}]
            exp=explain_aggregate(db.employees,pipe); coll="employees"
        elif endpoint == "late_leaderboard":
            pipe=[{"$match":{"date":{"$gte":first,"$lte":last}}},{"$group":{"_id":"$emp_code","total_late_minutes":{"$sum":{"$ifNull":["$late_minutes",0]}}}},{"$match":{"total_late_minutes":{"$gt":0}}}]
            exp=explain_aggregate(db.attendance_logs,pipe); coll="attendance_logs"
        else:
            if not department or not from_date or not to_date: raise HTTPException(422,"department, from and to are required")
            s,e=parse_date(from_date),parse_date(to_date)
            if e<s or (e-s).days+1>92: raise HTTPException(422,"invalid date range")
            pipe=[{"$match":{"date":{"$gte":from_date,"$lte":to_date}}},{"$lookup":{"from":"employees","localField":"emp_code","foreignField":"emp_code","as":"employee"}},{"$match":{"employee.department":department}}]
            exp=explain_aggregate(db.attendance_logs,pipe); coll="attendance_logs"
    return {"endpoint":endpoint,"collection":coll,"explain":mongo_json(exp)}
