"""Pure rule tests; endpoint/concurrency tests require a running MongoDB instance."""
import unittest
from datetime import datetime

from app.main import attendance_day, late_minutes, overtime_for_employee, work_hours


class AttendanceRuleTests(unittest.TestCase):
    def test_late_grace_boundary(self):
        # 09:30 IST is 04:00 UTC.
        self.assertEqual(late_minutes(datetime(2026, 7, 6, 4, 10, 0), "09:30", "2026-07-06"), 0)
        self.assertEqual(late_minutes(datetime(2026, 7, 6, 4, 10, 1), "09:30", "2026-07-06"), 10)

    def test_decimal_half_up_work_hours(self):
        # 3,618 seconds = 1.005 hours, which rounds half-up to 1.01.
        self.assertEqual(work_hours(datetime(2026, 7, 6, 4, 0), datetime(2026, 7, 6, 5, 0, 18)), 1.01)

    def test_overtime_minimum(self):
        emp = {"shift_start": "09:30", "shift_end": "18:30"}
        self.assertEqual(overtime_for_employee(datetime(2026, 7, 6, 13, 29, 59), emp, "2026-07-06"), 0)
        self.assertEqual(overtime_for_employee(datetime(2026, 7, 6, 13, 30), emp, "2026-07-06"), 30)

    def test_overnight_attendance_date(self):
        emp = {"shift_start": "22:00", "shift_end": "06:00"}
        # 05:59 IST on July 7 belongs to the shift that started July 6.
        self.assertEqual(attendance_day(datetime(2026, 7, 7, 0, 29), emp).isoformat(), "2026-07-06")
        self.assertEqual(attendance_day(datetime(2026, 7, 7, 0, 30), emp).isoformat(), "2026-07-07")


if __name__ == "__main__":
    unittest.main()
