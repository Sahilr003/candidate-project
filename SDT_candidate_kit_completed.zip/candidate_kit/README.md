# Employee Attendance & Analytics API

FastAPI + PyMongo implementation for the HROne Employee Attendance & Analytics assignment. The API contract and rules are defined in `openapi.yaml`; stored collection shapes are defined in `DATA_MODEL.md`.

## Requirements

- Python 3.11+
- MongoDB 6.0+ (MongoDB 7 recommended for the assignment)

## Local setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export MONGO_URI='mongodb://localhost:27017'
export MONGO_DB='attendance_db'
python sample_seed.py
uvicorn app.main:app --port 8000
```

The application also loads a local `.env` if present, but actual environment variables take precedence. Do not commit `.env` or secrets. Startup attempts to create the required indexes idempotently; `/health` reports whether MongoDB is reachable.

## Routes

Includes employee CRUD-style creation/listing, attendance punch-in/punch-out/listing/regularization, monthly and department analytics, late leaderboard, department trend, and explain-plan diagnostics. Interactive API documentation is available at `/docs`.

## Notes

Analytics are implemented with MongoDB aggregation pipelines. Verify the application against a running MongoDB 6+ instance and a 100,000-record test dataset before submission. The small sample data is not a substitute for edge-case or concurrency tests. Do not submit `.env`, credentials, a virtual environment, or database dumps.

## Local rule tests

```bash
python -m unittest discover -s tests
```

The rule tests cover timestamp boundaries, decimal half-up duration rounding, overtime thresholds, and overnight attendance dates. Endpoint integration, explain plans, and concurrency behavior must be exercised against a running MongoDB instance.
