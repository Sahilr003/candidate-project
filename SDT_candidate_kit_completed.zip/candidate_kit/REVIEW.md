# Starter code review

| # | Where (function / line) | What is wrong | How you'd notice it (test, input, or symptom) | How you fixed it |
|---|---|---|---|---|
| 1 | `compute_late_minutes` | It compares only a replaced clock time and does not model the employee's attendance date/overnight shift. | Punch into a 22:00–06:00 shift after midnight and inspect lateness. | Calculate against the shift start on the record's attendance date in IST. |
| 2 | `compute_late_minutes` | `int(total_seconds()/60)` truncates toward zero and the helper's threshold logic is too implicit around the exact 10-minute boundary. | Test 09:40:00 and 09:40:01 for a 09:30 shift. | Use whole-second timestamps and an explicit `> 600` second grace check. |
| 3 | `compute_work_hours` | Built-in `round` uses ties-to-even and binary floats, not decimal half-up. | Test a duration exactly at a half-cent rounding boundary. | Use `Decimal` and `ROUND_HALF_UP`. |
| 4 | `compute_overtime` | It always counts minutes after shift end and does not enforce the 30-minute minimum; it also mishandles overnight shifts. | Punch out 29:59 and 30:00 after shift end, including overnight. | Compute end instant on the proper shift day and apply the 30-minute threshold. |
| 5 | Mongo client setup | Defaults are acceptable for local use, but startup never creates the required indexes. | Inspect indexes on a fresh database. | Create idempotent unique and query-supporting indexes at startup. |
| 6 | `health` | Always returns success without checking MongoDB. | Stop MongoDB and request `/health`. | Ping MongoDB and return 503 on a database error. |
| 7 | `create_employee` | Check-then-insert is race-prone; duplicate code is not database-enforced. | Send simultaneous creates with the same `emp_code`. | Enforce a unique index and translate `DuplicateKeyError` to 409. |
| 8 | `create_employee` | `created_at` uses a naive local server clock rather than a normalized UTC instant and returns a datetime instead of epoch milliseconds. | Run under a non-UTC timezone and compare response type. | Store a whole-second UTC instant and serialize as epoch milliseconds. |
| 9 | `list_employees` | Skip calculation uses `page * page_size`, skipping the first page. | Request page 1 with page size 2. | Use `(page - 1) * page_size`. |
| 10 | `list_employees` | `total` ignores the department filter. | Filter by a department with fewer employees than the collection total. | Count with the same filter as the page query. |
| 11 | `list_employees` | No pagination bounds or query-side input validation. | Try page 0 or page_size 101. | Add FastAPI query validation and bounded pagination. |
| 12 | `punch_in` | Unknown employees cause a key error/500; the employee lookup result is not checked. | Punch in with an unknown `emp_code`. | Return 404 before using employee shift data. |
| 13 | `punch_in` | `punched_at` is interpreted in server-local time and seconds-looking, float, string, and out-of-range timestamps are not rejected. | Change server timezone or send `123`, `123.5`, or a string timestamp. | Validate epoch milliseconds, normalize to UTC, truncate to whole seconds, and derive the IST attendance date. |
| 14 | `punch_in` | Check-then-insert allows simultaneous duplicate punch-ins. | Race two requests for the same employee/date. | Enforce a unique `(emp_code, date)` index and return 409 on duplicate key. |
| 15 | `punch_in` | It returns an `id` even though `_id`/record IDs must not be part of the API contract. | Inspect a successful punch-in response. | Return only contract fields. |
| 16 | `list_attendance` | It loads all matching records into Python, sorts in memory, and paginates afterward. | Seed 100,000 records and monitor memory/latency. | Filter, sort, count, skip, and limit in MongoDB. |
| 17 | `list_attendance` | Sort tie-breaker is missing and response serialization exposes internal ObjectId-derived `id`. | Create multiple employees on the same date and inspect ordering/fields. | Sort by date descending then emp_code ascending; omit internal IDs. |
| 18 | All endpoints | Request/response models and status/date validation are largely absent. | Send malformed dates, invalid statuses, and invalid shift times. | Add Pydantic validation and explicit 404/409/422 handling. |
| 19 | Missing punch-out endpoint | No atomic transition protects against two simultaneous punch-outs. | Race two punch-outs against one open record. | Use conditional `find_one_and_update` with `punch_out: None`. |
| 20 | Missing regularization endpoint | No audit trail, derived-field recalculation, or concurrency guard exists. | Correct a record twice concurrently and inspect history. | Validate changes, recompute derived values, append one audit entry atomically, and reject stale updates with 409. |
| 21 | Missing analytics endpoints | Monthly, department, leaderboard, trend, and explain operations are absent. | Call each contracted route. | Implement aggregation-backed analytics and explain diagnostics. |

## Reviewed and retained

The natural attendance key is `(emp_code, date)`, not MongoDB `_id`; the date is an IST calendar string, while instants are BSON datetimes. Those choices in the supplied data model are intentional and were retained. The derived values remain stored authoritative values for analytics rather than being recomputed while reporting.
